
#ifndef __LUA_SKYNETCTYPT_H_
#define __LUA_SKYNETCTYPT_H_

int luaopen_crypt(lua_State *L);

#endif
